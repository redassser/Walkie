
# Walkie Use

## Press R to use the first ON walkie talkie in your inventory

Works if you are holding another item or the walkie talkie itself.

FULLY CLIENT SIDE!

Walkie talkie must be turned on first.
