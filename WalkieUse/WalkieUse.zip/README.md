
# Walkie Use

## Press R to use the first ON walkie talkie in your inventory

## Rebind from the in-game menu! 

Works if you are holding another item or the walkie talkie itself.

FULLY CLIENT SIDE!

Walkie talkie must be turned on first.

Rebind from the ingame rebind settings menu, now using Input Utils!

If you still want to use this mod without Input Utils, then v1.3.1 still works.
