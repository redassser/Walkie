
# Walkie Use

## Press R to use the first ON walkie talkie in your inventory

## Rebind from the in-game menu! 

Works if you are holding another item or the walkie talkie itself.

FULLY CLIENT SIDE!

Walkie talkie must be turned on first.

Rebind from the ingame rebind settings menu, should be at the bottom of the list
