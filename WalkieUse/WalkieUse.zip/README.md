
# Walkie Use

## Press R to use the first ON walkie talkie in your inventory

Works if you are holding another item or the walkie talkie itself.

All players must have the mod installed. (maybe havent tested. server owner for sure though)

Walkie talkie must be turned on first.
