## v1.5.0

Fixed compatibility with DesktopTerminal (Can use walkie key while on terminal) and AdvancedCompany (Walkie key does not interact with headset)

## v1.4.0

Input Utils added as a dependency to simplify and make it better.

## v1.3.1

You can now rebind your walkie toggle key from the in-game rebind settings! It should be the last one at the bottom. :)  

Quick fix!

## v1.2.2

Walkie now doesn't interfere with rotating in build mode

## v1.2.2

Made it so walkie does not activate when using terminal / chat or game is unfocused
