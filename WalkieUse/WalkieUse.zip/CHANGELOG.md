## v1.3.0

You can now rebind your walkie toggle key from the in-game rebind settings! It should be the last one at the bottom. :)  

## v1.2.2

Walkie now doesn't interfere with rotating in build mode

## v1.2.2

Made it so walkie does not activate when using terminal / chat or game is unfocused
