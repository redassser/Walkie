## v1.2.2

Walkie now doesn't interfere with rotating in build mode

## v1.2.2

Made it so walkie does not activate when using terminal / chat or game is unfocused
